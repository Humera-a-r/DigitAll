package com.example.digitall.UI.AgriTech;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.DialogFragment;

import com.example.digitall.R;
import com.example.digitall.databinding.TechnologymodulefragmentBinding;

public class TechnologyModuleFragment extends DialogFragment {
    TechnologymodulefragmentBinding technologymodulefragmentBinding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        technologymodulefragmentBinding= DataBindingUtil.inflate(inflater, R.layout.technologymodulefragment, container,false);
        View techView = technologymodulefragmentBinding.getRoot();
        return techView;
    }
}
