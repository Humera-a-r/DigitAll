package com.example.digitall.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.DialogFragment;

import com.example.digitall.R;
import com.example.digitall.databinding.WatermanagmentFragmentBinding;

public class WaterManagmentFragment extends DialogFragment {
    WatermanagmentFragmentBinding watermanagmentFragmentBinding;

    public static WaterManagmentFragment newInstance(){
        return new WaterManagmentFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        watermanagmentFragmentBinding= DataBindingUtil.inflate(inflater, R.layout.watermanagment_fragment, container, false);
        View managementView = watermanagmentFragmentBinding.getRoot();
        configureViewFinding();
        return managementView;
    }
    private void configureViewFinding() {
        AppCompatImageView imageBack = watermanagmentFragmentBinding.imageBack;
        imageBack.setOnClickListener(v -> dismiss());
    }
}
