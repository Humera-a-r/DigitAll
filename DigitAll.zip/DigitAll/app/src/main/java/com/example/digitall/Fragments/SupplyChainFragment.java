package com.example.digitall.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.DialogFragment;

import com.example.digitall.R;
import com.example.digitall.databinding.SupplychainFragmentBinding;

public class SupplyChainFragment extends DialogFragment {
    SupplychainFragmentBinding supplychainFragmentBinding;

    public static SupplyChainFragment newInstance() {
        return new SupplyChainFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        supplychainFragmentBinding = DataBindingUtil.inflate(inflater, R.layout.supplychain_fragment, container, false);
        View supplyView = supplychainFragmentBinding.getRoot();
        configureViewFinding();
        return supplyView;

    }

    private void configureViewFinding() {
        AppCompatImageView imageBack = supplychainFragmentBinding.imageBack;
        imageBack.setOnClickListener(v -> dismiss());
    }
}